#### 3장의 답
# 도전
# My 8 Ball

import random

# 답변을 입력해 봅시다.
ans1="자! 해보세요!"
ans2="됐네요, 이사람아"
ans3="뭐라고? 다시 생각해보세요."
ans4="모르니 두려운 것입니다."
ans5="칠푼인가요?? 제 정신이 아니군요!"
ans6="당신이라면 할 수 있어요!"
ans7="해도 그만, 안 해도 그만, 아니겠어요?"
ans8="맞아요. 당신은 올바른 선택을 했어요."

want_more_advice="y"

print("MyMagic8Ball에 오신 것을 환영합니다.")

# 사용자의 질문 얻기 (print 인자 사이의 빈칸을 없애기 위해 sep=""를 사용합니다.)
user_name = input("안녕. 당신의 이름을 입력하세요.\n")
print("만나서 반가워요.", user_name, ".", sep="")

while(want_more_advice == "y"):
    # 사용자의 질문 얻기
    question = input("조언을 구하고 싶으면 질문을 입력하고 엔터 키를 누르세요.\n")

    print("고민 중 ...\n" * 4)

    # 질문에 알맞은 답변을 하는 일에 randint() 함수를 활용합니다.
    choice=random.randint(1, 8)
    if choice==1:
        answer=ans1
    elif choice==2:
        answer=ans2
    elif choice==3:
        answer=ans3
    elif choice==4:
        answer=ans4
    elif choice==5:
        answer=ans5
    elif choice==6:
        answer=ans6
    elif choice==7:
        answer=ans7
    else:
        answer=ans8

    # 화면에 답변을 출력합니다.
    print(answer)

    want_more_advice = input("\n좀 더 충고가 필요한가요? y/n\n")

print("\안녕", user_name, ". 이용해주셔서 고마워요.", sep="")

input("\n\n끝내려면 엔터 키를 누르세요.")
