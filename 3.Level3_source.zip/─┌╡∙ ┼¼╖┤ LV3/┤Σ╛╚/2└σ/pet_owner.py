# pet_owner.py
# 이 도전을 해결하는 방법은 여러가지가 있습니다. 이 방법은 그 중 하나입니다.

import pet

# 2개의 동물을 만듭니다.
romeo = pet.Pet("타란툴라")
juliet = pet.Pet("피라냐")

# 거미와 놀아줍니다.
romeo.eat()
romeo.sleep()

# 물고기와 놀아줍니다.
juliet.eat()
juliet.sleep()
