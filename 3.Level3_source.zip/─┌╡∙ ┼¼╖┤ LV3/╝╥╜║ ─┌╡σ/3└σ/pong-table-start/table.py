# MyPong의 원본 Table 클래스를 생성합니다.
# 이 클래스는 Table의 처리 공간을 2D 직사각형으로 정의합니다.



class Table:
    #### 생성자
    

        
        # tkinter 공장으로부터 캔버스 주문:
        

        # tkinter 공장의 메서드를 사용하여 캔버스에 네트 추가:
        
        
