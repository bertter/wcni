# MyPong의 주된 파일을 만듭니다.



# tkinter 공장으로부터 윈도우 주문
    
       
# Table 공장으로부터 table 주문
        

# GUI를 계속 그리는 반복문 시작

