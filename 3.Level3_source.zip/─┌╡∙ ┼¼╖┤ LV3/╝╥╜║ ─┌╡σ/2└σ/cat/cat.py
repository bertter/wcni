# cat.py가 제공하는 Cat 클래스

class Cat:
    def speak(self):
        print("야옹!")

    def drink(self):
        print("고양이가 우유를 마셔요.")
        print("고양이가 낮잠을 잡니다.")
