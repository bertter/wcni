# main.py

import cat

# Romeo라는 이름의 cat 인스턴스 생성
romeo = cat.Cat()

# Romeo 실행
romeo.speak()
romeo.drink()
