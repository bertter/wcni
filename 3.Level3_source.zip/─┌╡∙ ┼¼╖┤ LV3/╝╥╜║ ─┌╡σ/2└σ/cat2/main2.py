# main2.py

import cat2

# 2개의 cat 인스턴스 생성
romeo = cat2.Cat("Romeo")
juliet = cat2.Cat("Juliet")

# 로미오와 놀아준다.
romeo.speak()
romeo.drink()

# 줄리엣과 놀아준다.
juliet.speak()
juliet.drink()
