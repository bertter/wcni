# 이 파일은 원래 MyPong을 위해 만든 Bat 클래스입니다.
# 이 클래스는 Bat의 처리 공간을 2D 직사각형으로 정의합니다.

import table

class Bat:
    #### 생성자
    


    #### 메서드


    
